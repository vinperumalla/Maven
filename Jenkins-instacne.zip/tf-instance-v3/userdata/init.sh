#!/bin/sh
Jenkins_UI_UserName="$1"
Jenkins_UI_Password="$2"

# firewall installation
sudo apt-get update
sudo apt-get install -y firewalld
sudo firewall-cmd --zone=public --add-port=8080/tcp --permanent
sudo firewall-cmd --reload

echo "-------------------------------------------------Update the packages-------------------------------------------------"
sudo apt-get update -y

echo "-------------------------------------------------First install Java-------------------------------------------------"
sudo apt-get install openjdk-8-jre-headless -y

echo "-------------------------------------------------Add the key and source list to apt for Jenkins-------------------------------------------------"
sudo wget -q -O - https://pkg.jenkins.io/debian/jenkins-ci.org.key | apt-key add -

echo "-------------------------------------------------Now create source list for Jenkins-------------------------------------------------"
sudo sh -c 'echo deb http://pkg.jenkins.io/debian-stable binary/ > /etc/apt/sources.list.d/jenkins.list'

echo "-------------------------------------------------Update the packages-------------------------------------------------"
sudo apt-get update -y

echo "-------------------------------------------------Install jenkins-------------------------------------------------"
sudo apt-get install -y  jenkins
sleep 15
#Configuring Jenkins
echo "---Configuring Jenkins---"
sleep 15
sudo wget -P /usr/share/jenkins http://localhost:8080/jnlpJars/jenkins-cli.jar
sleep 15
sudo java -jar /usr/share/jenkins/jenkins-cli.jar -s http://localhost:8080 who-am-i
#creating jenkins user
echo "New jenkins user created"
echo "jenkins.model.Jenkins.instance.securityRealm.createAccount("\'"$Jenkins_UI_UserName"\'","\'"$Jenkins_UI_Password"\'")"| java -jar /usr/share/jenkins/jenkins-cli.jar -auth admin:`cat /var/lib/jenkins/secrets/initialAdminPassword` -s http://localhost:8080 groovy =